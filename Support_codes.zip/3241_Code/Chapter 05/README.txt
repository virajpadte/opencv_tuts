This directory contains material supporting chapter 5 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
by Robert Laganiere, Packt Publishing, 2011.

File:
	morphology.cpp
correspond to Recipes:
Eroding and Dilating Images using Morphological Filters
Opening and Closing Images using Morphological Filters

Files:
	morpho2.cpp
	morphoFeatures.h
correspond to Recipe:
Detecting edges and corners using morphological filters

Files:
	segment.cpp
	watershedSegmentation.h
correspond to Recipe:
Segmenting images using watersheds